package com.vivalnk.sdk.app.base.app;

/**
 * Created by JakeMo on 18-4-30.
 */
public class AppConstants {

}
