package com.vivalnk.sdk.app.base.widget;

/**
 * Created by JakeMo on 18-5-6.
 */
public class EcgPoint {

  //milli seconds
  public long time;
  public float mv;
  public float y;
  public int color;
}
