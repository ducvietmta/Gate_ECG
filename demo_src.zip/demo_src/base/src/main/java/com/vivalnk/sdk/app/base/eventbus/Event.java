package com.vivalnk.sdk.app.base.eventbus;

/**
 * Created by JakeMo on 18-5-2.
 */
public class Event<T> {
  public T data;
  public String code;
  public String msg;
}
