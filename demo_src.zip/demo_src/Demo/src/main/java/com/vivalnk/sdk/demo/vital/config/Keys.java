package com.vivalnk.sdk.demo.vital.config;

/**
 * Created by JakeMo on 18-7-15.
 */
public class Keys {
  public static String ota_fw_selected = "ota_fw_selected";
  public static String ota_bl_selected = "ota_bl_selected";
}
