package com.vivalnk.sdk.demo.vital.mvp.contract;

import com.vivalnk.sdk.app.base.mvp.IModel;
import com.vivalnk.sdk.app.base.mvp.IView;

/**
 * 设备菜单
 *
 * @author Aslan
 * @date 2019/3/27
 */
public class DeviceMenuContract {

  public interface Model extends IModel {

  }

  public interface View extends IView {

  }
}
