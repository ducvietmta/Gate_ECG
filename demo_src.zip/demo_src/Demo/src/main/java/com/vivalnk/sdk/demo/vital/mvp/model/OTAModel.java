package com.vivalnk.sdk.demo.vital.mvp.model;

import com.vivalnk.sdk.demo.vital.mvp.contract.OTAContract;

/**
 * Created by JakeMo on 18-7-25.
 */
public class OTAModel implements OTAContract.Model {

  @Override
  public void onDestroy() {

  }
}
